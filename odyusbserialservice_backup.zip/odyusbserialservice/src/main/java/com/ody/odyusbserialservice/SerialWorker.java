package com.ody.odyusbserialservice;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.hardware.usb.UsbRequest;
import android.util.Log;

import com.ody.odyusbserialservice.helpers.USBPort;
import com.ody.odyusbserialservice.helpers.USBPortConnection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import tw.com.prolific.driver.pl2303.PL2303Driver;

import static java.util.regex.Pattern.CASE_INSENSITIVE;

public class SerialWorker {

    private static UsbManager mUsbManager;
    private static USBPort port;
    USBPortConnection portConnection;
    private static UsbDevice mDevice;
    private String TAG = "ODY_Scale";
    String result = "";

    private PL2303Driver.BaudRate mBaudrate = PL2303Driver.BaudRate.B9600;

    private static final String ACTION_USB_PERMISSION = "com.genericusb.mainactivity.USB_PERMISSION";

    PL2303Driver pl2303Driver;

    public String main(Context context, int deviceVID) {
        boolean seek = true;
        String result = "no value";

        //register the required permission
        PendingIntent mPermissionIntent = PendingIntent.getBroadcast(context, 0,
                new Intent(ACTION_USB_PERMISSION), 0);

        //setup manager and port
        mUsbManager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        port = new USBPort(mUsbManager);

        HashMap<String, UsbDevice> usblist = mUsbManager.getDeviceList();
        Iterator<String> iterator = usblist.keySet().iterator();

        while (iterator.hasNext() && seek) {
            //validate against vendorid
            mDevice = (UsbDevice) usblist.get(iterator.next());
            if (mDevice.getVendorId() == deviceVID) {
                seek = false;//stop while loop

                Log.i(TAG, "SerialManager: device found");

                if (!mUsbManager.hasPermission(mDevice)) { //prompt permission
                    mUsbManager.requestPermission(mDevice, mPermissionIntent);
                } else { //permission granted
                    try {

                        if (pl2303Driver == null) {
                            pl2303Driver = new PL2303Driver(mUsbManager,
                                    context, ACTION_USB_PERMISSION);
                        }

                        if (pl2303Driver.PL2303USBFeatureSupported()) {
                            Log.i(TAG, "SerialManager: pl2303 Supported");

                            //time to attempt a connection to the device
                            if (!pl2303Driver.isConnected()) {

                                Log.i(TAG, "PL2303 Driver: pl2303Driver not connected, connecting");

                                if (pl2303Driver.enumerate()) {//port is opened within .enumerate()

                                    Log.i(TAG, "PL2303 Driver-init: pl2303Driver connection succeeded");

                                    Thread.sleep(200);

                                    if (pl2303Driver.InitByBaudRate(mBaudrate, 300)) {
                                        Log.i(TAG, "PL2303 Device-init: device connection succeeded");

                                        //read from the device
                                        Thread.sleep(30);
                                        result = io(pl2303Driver);

                                        Log.i(TAG, "PL2303 Driver-init: killing driver");

                                    } else {
                                        if (!pl2303Driver.PL2303Device_IsHasPermission()) {
                                            Log.i(TAG, "PL2303 Device-init: device permission issue");
                                        }
                                    }
                                }
                            } else { //driver is already connected
                                if (pl2303Driver.InitByBaudRate(mBaudrate, 300)) {

                                    Log.i(TAG, "PL2303 Device: device connection succeeded");

                                    //read from the device
                                    Thread.sleep(30);
                                    result = io(pl2303Driver);

                                    Log.i(TAG, "PL2303 Device: killing driver");

                                } else {
                                    if (!pl2303Driver.PL2303Device_IsHasPermission()) {
                                        Log.i(TAG, "PL2303 Driver: device permission issue");
                                    }
                                }
                            }
                        } else {
                            Log.i(TAG, "SerialManager: pl2303 NOT Supported");
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "SerialManager: error in connecting to port", e);
                    } finally {
                        if (pl2303Driver != null) {
                            pl2303Driver.end();
                            pl2303Driver = null;
                        }

                        if(port != null && mDevice != null){
                            try {
                                port.connect_device(mDevice).close();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            } else {
                Log.i(TAG, "SerialManager: device not found");
            }
        }
        return result;
    }

    public String io(PL2303Driver instance) {
        Log.i(TAG, "Reader: entered");
        String result = "no value";
        try {
            result = read(instance);

            Thread.sleep(30);
            Log.i(TAG, "Reader: thread sleep");

        } catch (InterruptedException e) {
            Log.i(TAG, "Reader: thread sleep broke");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    public String read(PL2303Driver instance) {
        String result = "no match";
        byte[] rbuf = new byte[40];
        try {
            int len;
            int timeOut = 0;
            StringBuffer sbHex = new StringBuffer();
            do {
                timeOut++;
                Thread.sleep(200);
                len = instance.read(rbuf);
                Log.i(TAG, "Reader read-loop: Length of read " + len + "instance connection: " + instance.isConnected() + "::time out count - " + timeOut);
            } while (len < 20 && timeOut < 15);

            if (len > 0) {
                Log.i(TAG, "Reader: Length of read " + len);
                for (int j = 0; j < len; j++) {
                    sbHex.append((char) (rbuf[j] & 0x000000FF));
                }
                final String regex = "([\\d]{3}.[\\d]{3})(?!\\s+.(.).\\1)\\b";
                Pattern p = Pattern.compile(regex, CASE_INSENSITIVE);
                Matcher matcher = p.matcher(sbHex.toString());
                if (matcher.find()) {
                    result = matcher.group();
                } else {
                    Log.i(TAG, "Matcher: no match found");
                    result = read(instance);
                }
            } else if (timeOut == 15) {
                result = "timeout";
                Log.i(TAG, "read: Timed out " + timeOut);
            }else{
                Log.i(TAG, "read: leng > 0 " + len);
            }
        } catch (Exception e) {
            Log.e(TAG, "read: whoops", e);
        }
        return result;
    }
}
